package com.ts.dao;

import java.util.List;

import com.rest.dto.ConcertInfo;
import com.rest.dto.ConcertReg;
import com.ts.db.HibernateTemplate;

public class ConcertRegDAO {
	public int add(ConcertReg concertreg) {		
		return HibernateTemplate.addObject(concertreg);
	}
	public List<ConcertReg> getAllConcertReg() {
		List<ConcertReg> concertreg=(List)HibernateTemplate.getObjectListByQuery("From ConcertReg");

		return concertreg;	
	}


}

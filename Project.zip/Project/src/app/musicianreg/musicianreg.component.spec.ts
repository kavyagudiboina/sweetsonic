import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MusicianregComponent } from './musicianreg.component';

describe('MusicianregComponent', () => {
  let component: MusicianregComponent;
  let fixture: ComponentFixture<MusicianregComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MusicianregComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MusicianregComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

import { UserService } from '../user.service';

@Component({
  selector: 'app-musicianreg',
  templateUrl: './musicianreg.component.html',
  styleUrls: ['./musicianreg.component.css']
})
export class MusicianregComponent implements OnInit {

  musician: any;
  
  
  constructor(private router : Router ,private userService: UserService,) {
    this.musician = {musicianId: '', musicianName: '', locality: '', skills: '' ,mob : '',experience:'',status:''}
  }
ngOnInit(): void {
 // throw new Error("Method not implemented.");
}
regMusician(musicianregister:any) : void{
  console.log('registerUser method is called...');
 // console.log(this.user);
 this.musician.musicianId = 0
 this.userService.regMusician(this.musician).subscribe(
   res =>console.log(res),
   err => console.log(err)
 )

}
goToPagehome():void{
  this.router.navigateByUrl('home');
}
}

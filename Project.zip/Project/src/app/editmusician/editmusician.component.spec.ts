import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditmusicianComponent } from './editmusician.component';

describe('EditmusicianComponent', () => {
  let component: EditmusicianComponent;
  let fixture: ComponentFixture<EditmusicianComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditmusicianComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditmusicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

declare var jQuery:any;

@Component({
  selector: 'app-editmusician',
  templateUrl: './editmusician.component.html',
  styleUrls: ['./editmusician.component.css']
})
export class EditmusicianComponent implements OnInit {

  musicians: any;
  editObject: any;
  constructor(private service: UserService,private router: Router) {
 
  this.editObject = {musicianId: '', musicianName: '', locality: '', skills: '' , experience: '',status:'',mob:''};
}

  ngOnInit() {
   this.service.getAllMusicians().subscribe((result: any) => { console.log(result); this.musicians= result; });
  }
 deleteMusicians(musician: any) {
    /*this.service.deleteMusicians(musician).subscribe((result: any) => {
      console.log("deleted");
  const i = this.musicians.findIndex((element) => {return element.musicianId === musician.musicianId;
      });
  this.musicians.splice(i , 1);
    });*/
    console.log(musician)
    console.log(musician.musicianId)

    this.service.deleteMusicians(musician).subscribe((result: any) => {
    });
    
    
  }
  showEditPopup(musicians: any) {
    this.editObject = musicians;
    jQuery('#musicianModel').modal('show');
  }
  updateMusicians() {
    this.service.updateMusicians(this.editObject).subscribe();
    console.log(this.editObject);
  }







  goToPageAdminhome():void{
    this.router.navigateByUrl('adminhome');
 }
 

}

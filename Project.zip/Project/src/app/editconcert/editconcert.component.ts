import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-editconcert',
  templateUrl: './editconcert.component.html',
  styleUrls: ['./editconcert.component.css']
})
export class EditconcertComponent implements OnInit {
  concerts: any;
  editObject: any;
  constructor(private service: UserService) {
 
  this.editObject = { concertId:'',concertName: '', concertDate:'',concertVenue:'',totalTickets:'',availableTickets:'',bookedTickets:'',ticketPrice:''};
}

  ngOnInit() {
   this.service.getAllConcerts().subscribe((result: any) => { console.log(result); this.concerts= result; });
  }


}

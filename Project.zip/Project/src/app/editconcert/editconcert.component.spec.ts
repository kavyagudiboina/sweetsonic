import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditconcertComponent } from './editconcert.component';

describe('EditconcertComponent', () => {
  let component: EditconcertComponent;
  let fixture: ComponentFixture<EditconcertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditconcertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditconcertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

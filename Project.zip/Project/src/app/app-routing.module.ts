import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './auth.guard';
import { MusiciansComponent } from './musicians/musicians.component';
import {ConcertsComponent } from './concerts/concerts.component';
import { HomeComponent } from './home/home.component';
import { ViewconcertsComponent } from './viewconcerts/viewconcerts.component';
import { MusicianregComponent } from './musicianreg/musicianreg.component';
import { GetUsersComponent } from './get-users/get-users.component';
import { GetmusicianbylocalityComponent } from './getmusicianbylocality/getmusicianbylocality.component';
import { EditmusicianComponent } from './editmusician/editmusician.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddconcertComponent } from './addconcert/addconcert.component';
import { AddmusiciansComponent } from './addmusicians/addmusicians.component';
import { MainComponent } from './main/main.component';
import { PageComponent } from './page/page.component';
import { BookconcertComponent } from './bookconcert/bookconcert.component';
import { PracticeComponent } from './practice/practice.component';

 
const routes: Routes = [
                       // {path:'', component:LoginComponent},
                        {path: 'login', component: LoginComponent},                        
                         {path:'register',component : RegisterComponent},
                         {path:'main',component : MainComponent},
                         {path: "",  component: PageComponent, pathMatch: "full"},

                        
                       {path: 'musicians', canActivate: [AuthGuard], component: MusiciansComponent},
                       {path: 'concerts', canActivate: [AuthGuard], component: ConcertsComponent},

                       {path: 'home', canActivate: [AuthGuard], component: HomeComponent},
                       {path: 'adminhome', canActivate: [AuthGuard], component: AdminhomeComponent},

                            {path: 'viewconcerts', canActivate: [AuthGuard], component: ViewconcertsComponent},
                            {path: 'musicianreg', canActivate: [AuthGuard], component: MusicianregComponent},
                            {path: 'get-users', canActivate: [AuthGuard], component:GetUsersComponent},
                            {path: 'getmusicianbylocality', canActivate: [AuthGuard], component:GetmusicianbylocalityComponent},
                            {path: 'editmusician',  component:EditmusicianComponent},
                            {path: 'addconcert', canActivate: [AuthGuard], component:AddconcertComponent},
                            {path: 'addmusicians', canActivate: [AuthGuard], component:AddmusiciansComponent},
                            {path: 'bookconcert', canActivate: [AuthGuard], component:BookconcertComponent},



                           {path: 'practicecomponent',component: PracticeComponent, // this is the component with the <router-outlet> in the template
                                              children: [
                                                {
        path: 'viewconcerts', // child route path
        component: ViewconcertsComponent, // child route component that the router renders
      },
      
    
    ],
  }                    
                     
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

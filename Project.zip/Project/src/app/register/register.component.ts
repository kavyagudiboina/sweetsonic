import { Component,OnInit } from '@angular/core';
import {UserService} from './../user.service';
import { Router } from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule, ToastrService} from 'ngx-toastr';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";  
  mobNumberPattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
    user: any;
  
  
    constructor(private router : Router ,private userService: UserService,private toastr : ToastrService) {
      this.user = {userId: '', userName: '', email: '', password: '' ,mob : ''}
    }
  ngOnInit(): void {
   // throw new Error("Method not implemented.");
  }
  registerUser(registerform:any) : void{
    console.log('registerUser method is called...');
   // console.log(this.user);
   this.user.userId = 0
   this.userService.registerUser(this.user).subscribe(
     res =>console.log(res),
     err => console.log(err)
   ) ;     this.toastr.success("Registeration Success");


  }
  goToPageLogin():void{
    this.router.navigateByUrl('login');
 }
  
  
 //register(registerform:any): void {
    //this.user.userId=0;
  //  this.userService.registerUser(this.user).subscribe((result: any) => { console.log(result);this.user=result; } );
  //  console.log(this.user);
  //}

  
 
}  
  



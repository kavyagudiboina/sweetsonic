import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { AuthGuard } from './auth.guard';
import { FooterComponent } from './footer/footer.component';
import { MusiciansComponent } from './musicians/musicians.component';
import { ConcertsComponent } from './concerts/concerts.component';
import { HomeComponent } from './home/home.component';
import { UserService } from './user.service';
import { ViewconcertsComponent } from './viewconcerts/viewconcerts.component';
import { MusicianregComponent } from './musicianreg/musicianreg.component';
import { MainComponent } from './main/main.component';
import { GetUsersComponent } from './get-users/get-users.component';
import { GetmusicianbylocalityComponent } from './getmusicianbylocality/getmusicianbylocality.component';
import { BookconcertComponent } from './bookconcert/bookconcert.component';
import { EditmusicianComponent } from './editmusician/editmusician.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { EditconcertComponent } from './editconcert/editconcert.component';
import { AddconcertComponent } from './addconcert/addconcert.component';
import { AddmusiciansComponent } from './addmusicians/addmusicians.component';
import { PageComponent } from './page/page.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr'
import { timeout } from 'rxjs/operators';
import { ReactiveFormsModule } from '@angular/forms';

import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { PracticeComponent } from './practice/practice.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    MusiciansComponent,
    ConcertsComponent,
    HomeComponent,
    ViewconcertsComponent,
    MusicianregComponent,
    MainComponent,
    GetUsersComponent,
    GetmusicianbylocalityComponent,
    BookconcertComponent,
    EditmusicianComponent,
    AdminhomeComponent,
    EditconcertComponent,
    AddconcertComponent,
    AddmusiciansComponent,
    PageComponent,
    PracticeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
   
    ToastrModule.forRoot({
    timeOut:3000 ,
    progressBar : true,
    progressAnimation:'increasing',
    preventDuplicates:true

    
    })

  ],
 
providers: [AuthGuard,UserService],
bootstrap: [AppComponent]
})
export class AppModule { }

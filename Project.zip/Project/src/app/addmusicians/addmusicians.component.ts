import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-addmusicians',
  templateUrl: './addmusicians.component.html',
  styleUrls: ['./addmusicians.component.css']
})
export class AddmusiciansComponent implements OnInit {

  musician: any;
  
  
  constructor(private router : Router ,private userService: UserService,private toastr : ToastrService) {
    this.musician = {musicianId: '', musicianName: '', locality: '', skills: '' ,mob : '',experience:'',status:''}
  }
ngOnInit(): void {
 // throw new Error("Method not implemented.");
}
regMusician(musicianregister:any) : void{
  console.log('registerUser method is called...');
 // console.log(this.user);
 this.musician.musicianId = 0
 this.userService.regMusician(this.musician).subscribe(
   res =>console.log(res),
   err => console.log(err)
 );this.toastr.success("Musician Added Successfully")

}

goToPageAdminhome():void{
  this.router.navigateByUrl('adminhome');
}

}

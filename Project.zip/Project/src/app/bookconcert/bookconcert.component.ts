import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
declare var jQuery:any;


@Component({
  selector: 'app-bookconcert',
  templateUrl: './bookconcert.component.html',
  styleUrls: ['./bookconcert.component.css']
})
export class BookconcertComponent implements OnInit {
  [x: string]: any;
  concertreg : any
  concerts: any;
  editObject: any;
  id: number;

  
  route: any;

  constructor(private service: UserService,private router : Router) {
    this.concertreg = {
      regId:'',numofTickets : '',totalbill :'',concertInfo : {concertId:''},
      user :{email:''},
      
      }
   }

  ngOnInit(): void {

    this.service.getAllConcertReg().subscribe((result: any) => { console.log(result); this.concertregs= result; });

  }
  
 
}  










 
  
  


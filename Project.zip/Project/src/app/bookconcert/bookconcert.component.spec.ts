import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookconcertComponent } from './bookconcert.component';

describe('BookconcertComponent', () => {
  let component: BookconcertComponent;
  let fixture: ComponentFixture<BookconcertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookconcertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookconcertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

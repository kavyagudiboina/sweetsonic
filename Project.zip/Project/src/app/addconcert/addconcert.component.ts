import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-addconcert',
  templateUrl: './addconcert.component.html',
  styleUrls: ['./addconcert.component.css']
})
export class AddconcertComponent implements OnInit {


  concert: any;
  
  
  constructor(private router : Router ,private userService: UserService,private toastr : ToastrService) {
    this.concert = {concertId: '', concertName: '', concertDate: '', concertVenue: '' ,availableTickets : '',totalTickets:'',bookedTickets:'',ticketPrice:''}
  }
ngOnInit(): void {
 // throw new Error("Method not implemented.");
}
addConcert(add:any) : void{
  console.log('addConcert method is called...');
 // console.log(this.user);
 this.concert.concertId = 0
 this.userService.addConcert(this.concert).subscribe(
   res =>console.log(res),
   err => console.log(err)
 );this.toastr.success("Concert Added Successfully")

}

goToPageAdminhome():void{
  this.router.navigateByUrl('adminhome');
}

}

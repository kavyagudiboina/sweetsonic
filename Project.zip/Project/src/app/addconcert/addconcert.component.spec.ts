import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddconcertComponent } from './addconcert.component';

describe('AddconcertComponent', () => {
  let component: AddconcertComponent;
  let fixture: ComponentFixture<AddconcertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddconcertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddconcertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

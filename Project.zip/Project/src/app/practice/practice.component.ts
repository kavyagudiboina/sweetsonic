/*import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.css']
})
export class PracticeComponent implements OnInit {

  editProfileForm: FormGroup;
  concertreg : any
  concerts: any;
  editObject: any;
  id: number;

  concert:any;
  route: any;

  constructor(private service: UserService,private router : Router) {
    this.editObject = { concertId:'',concertName: '', concertDate:'',concertVenue:'',totalTickets:'',availableTickets:'',bookedTickets:'',ticketPrice:''};

   }

  ngOnInit(): void {

   this.service.getAllConcerts().subscribe((result: any) => { console.log(result); this.concerts= result; });
  
   
  }
 
 
 getConcertById(id:any)
    {
        alert(id);
        this.service.getConcertById(id).subscribe((result: any) => {console.log(result); this.concerts = result; });
        alert(this.concert.concertName);
        /*this.editProfileForm.patchValue({
          firstname: this.concert.concertName,
          lastname: this.concert.concertDate,
          username: this.concert.concertVenue,
          email: this.concert.ticketPrice
      });
       }
 
}*/

import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.css']
})
export class PracticeComponent implements OnInit {
  concert:any;
  route: any;
  numofTickets : any;
  editObject: { concertId: string; concertName: string; concertDate: string; concertVenue: string; totalTickets: string; availableTickets: string; bookedTickets: string; ticketPrice: string; };
  concerts: any;

  constructor(private service: UserService,private router : Router) {
    this.editObject = { concertId:'',concertName: '', concertDate:'',concertVenue:'',totalTickets:'',availableTickets:'',bookedTickets:'',ticketPrice:''};

   }
  ngOnInit(): void {
    this.service.getAllConcerts().subscribe((result: any) => { console.log(result); this.concerts= result; });

  }

  showModal : boolean;
  id    : string;
  name : string;
  date  : string;
  venue     : string;
  price     : string;
list : any = [];
  getConcertById(id:any)
    {
        
        this.service.getConcertById(id).subscribe((result: any) => { console.log(result); this.concerts= result; 
          this.list = this.concerts ;
          console.log(this.list)
        this.showModal = true; // Show-Hide Modal Check
      this.id = id;
      this.name = this.list.concertName
      console.log(this.name);
      console.log(this.id)
    });
    
  }
  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
  }

  goToPageConcerts():void{
    this.router.navigateByUrl('viewconcerts');
 }

}


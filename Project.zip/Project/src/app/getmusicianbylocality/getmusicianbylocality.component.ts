import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-getmusicianbylocality',
  templateUrl: './getmusicianbylocality.component.html',
  styleUrls: ['./getmusicianbylocality.component.css']
})
export class GetmusicianbylocalityComponent implements OnInit {
  musicians:any;
  locality:any;

  constructor(private service : UserService,private router:Router) { }

  ngOnInit(): void {
  }
  getMusicianByLocality() {
    this.service.getMusicianByLocality(this.locality).subscribe((result: any) => {console.log(result); this.musicians = result; });
    }
    goToPagehome():void{
      this.router.navigateByUrl('home');
   }
}

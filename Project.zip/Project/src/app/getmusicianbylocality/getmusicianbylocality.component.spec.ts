import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetmusicianbylocalityComponent } from './getmusicianbylocality.component';

describe('GetmusicianbylocalityComponent', () => {
  let component: GetmusicianbylocalityComponent;
  let fixture: ComponentFixture<GetmusicianbylocalityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetmusicianbylocalityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetmusicianbylocalityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { FormControl, FormGroup, Validators} from '@angular/forms';


import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
 // private _registerUrl = "http://localhost:8080/RESTAPI2018/webapi/myresource1/registerUser"  
  private result  :any;
  private isUserLogged: any;
  
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  
   getAllUser(): any {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getAllUser');
   }
   getUserById(userId: any) {
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getUserById/' + userId);
   }
   registerUser(user:any) {
    console.log(user)
   
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/regUser' ,user);
    
   }
  
   loginUser(loginId:any, password:any){
     this.result = loginId +  ' ' + password ;
     return this.httpClient.get('RESTAPI2018/webapi/myresource1/loginUser/'+this.result);
   }

   getAllMusicians():any{
    return this.httpClient.get('/RESTAPI2018/webapi/myresource1/getAllMusicians/');


   }
   getAllConcerts():any{
    return this.httpClient.get('/RESTAPI2018/webapi/myresource1/getAllConcerts/');


   }
   getAllConcertReg():any{
    return this.httpClient.get('/RESTAPI2018/webapi/myresource1/getAllConcertReg/');


   }

   regMusician(musician:any){
    console.log(musician)
   
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/regMusician' ,musician);
    


   }
  getMusicianByLocality(locality:any){
    return this.httpClient.get('RESTAPI2018/webapi/myresource1/getMusicianByLocality/' + locality);


  }
  deleteMusicians(musician: any) {
    console.log(musician.musicianId)
    return this.httpClient.get('RESTAPI/webapi/myresource/deleteMusician/' +musician.musicianId);
   }

   updateMusicians(editObject: any) {
    return this.httpClient.put('RESTAPI/webapi/myresource/updateMusicians', editObject);
   }
   
   
   addConcert(concert:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/addConcert' ,concert);


   }
   addConcertReg(concertreg:any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource1/addConcertReg' ,concertreg);


   }
   getConcertById(concertId:any){
     return this.httpClient.get('RESTAPI2018/webapi/myresource1/getConcertById/' + concertId);
   }

}


import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import * as jquery from 'jquery'
import { ToastrService } from 'ngx-toastr';
declare var jQuery:any;

@Component({
  selector: 'app-viewconcerts',
  templateUrl: './viewconcerts.component.html',
  styleUrls: ['./viewconcerts.component.css']
})
export class ViewconcertsComponent implements OnInit {
  display='none';
  concerts: any;
  editObject: any;
  numofTickets : any = "" ;
  price : any;
  concertreg:any;
  p1:any;
  concert:any;
  route: any;
  showModal : boolean;
  fullName: any = "Hello JavaTpoint";    


list : any = [];
  userdetails: any;
  concertDetails: any;
  constructor(private router : Router,private userService: UserService,private toastr : ToastrService ) {
  
  this.concertreg = {
  regId:'',numofTickets : '',totalbill :'',concertInfo : {concertId:''},
  user :{email:''},
  
  }
}

  ngOnInit() {
    
    this.userdetails = JSON.parse(localStorage.getItem("currentUser"));
    console.log(this.userdetails.email);
   // this.concertreg.email = this.userdetails.email;
    console.log(this.concertreg);
   
   
   this.userService.getAllConcerts().subscribe((result: any) => { console.log(result); this.concerts= result; });
  }
  addConcertreg(add:any) : void{
    console.log('addConcert method is called...');
    this.concertreg.regId = 0
   // this.concertreg.totalBill = this.concertreg.NumofTickets * this.list.ticketPrice;
   this.concertreg.numofTickets = this.concertreg.numofTickets;
   this.concertreg.totalbill = this.concertreg.numofTickets * this.list.ticketPrice;
   this.concertreg.concertInfo.concertId = this.list.concertId;
   this.concertreg.user.email= this.userdetails.email;
   console.log(this.concertreg);
 this.userService.addConcertReg(this.concertreg).subscribe(
   res =>console.log(res),
   err => console.log(err)
 );this.toastr.success("Booking Successfull")

  
  }
  
  /*showEditPopup(concerts: any) {
  
    this.price = concerts.ticketPrice * this.numofTickets ;
    jQuery('#myModel').modal('show');
  }*/

  
 

  goToPagehome():void{
    this.router.navigateByUrl('home');
  }
async getConcertById(id:any)
{
    
   await this.userService.getConcertById(id).subscribe((result: any) => { console.log(result); this.list= result; 
      localStorage.setItem('currentConcert', JSON.stringify(this.list));
      
     // this.concertDetails = JSON.parse(localStorage.getItem("currentConcert"));
      //console.log(this.concertDetails)
      //this.concertreg.concertId = id;
     // console.log(this.concertreg.concertId);


      console.log(this.concertreg);

    this.showModal = true; // Show-Hide Modal Check

});

}
}
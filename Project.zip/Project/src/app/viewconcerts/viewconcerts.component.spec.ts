import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewconcertsComponent } from './viewconcerts.component';

describe('ViewconcertsComponent', () => {
  let component: ViewconcertsComponent;
  let fixture: ComponentFixture<ViewconcertsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewconcertsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewconcertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

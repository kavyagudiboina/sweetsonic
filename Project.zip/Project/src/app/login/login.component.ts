import { Component, OnInit, Injectable } from '@angular/core';
import {UserService} from './../user.service';
import {Router, ActivatedRoute} from '@angular/router';
import { ToastrService } from 'ngx-toastr';





@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  

  user : any;
  result:any;
 public login : any;
  service: any;
  
  constructor(public userService: UserService,
    private router :Router,
    private route: ActivatedRoute,
    private toastr:ToastrService) { 
      this.login = {email:'', password:''}
     
    }
  


  
   ngOnInit(): void {
  }

  
  loginUser() : void{
    console.log('loginUser method is called...');
    console.log(this.login);
  }
  
 async validateUser(loginForm : any){
    
    if(this.login.email === "admin@gmail.com" && this.login.password === "admin" ){
      this.userService.setUserLoggedIn();
      this.toastr.success("Login Success");
      this.router.navigate(['adminhome']);
    }else{
      await this.userService.loginUser(this.login.email,this.login.password).subscribe((result:any)=>{this.user = result;
      if (this.user != null){
        this.userService.setUserLoggedIn();

        this.toastr.success("Login Success");
        localStorage.setItem('currentUser', JSON.stringify(this.user));


        this.router.navigate(['home']);

      }else{
        //console.log(loginForm.err);
        //this.toastr.error("Login Failed");
        this.router.navigate(['home']);
        this.toastr.error("Login Failed");

      }
      });
    console.log('validateUser methos is called...');
   console.log(this.user);
  }

}

}

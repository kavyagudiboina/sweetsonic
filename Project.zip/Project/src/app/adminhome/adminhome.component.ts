import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  constructor(private router: Router) { }

 // goToPage(pageName:string):void{
//    this.router.navigate([`$(pageName)`]);
//  }
goToPageUsers():void{
     this.router.navigateByUrl('get-users');
  }
  goToPageEditmusicians():void{
    this.router.navigateByUrl('editmusician');
 }
 goToPageAddConcert():void{
  this.router.navigateByUrl('addconcert');
}
goToPageAddmusicians():void{
 this.router.navigateByUrl('addmusicians');
}
goToPageConcertReg():void{
  this.router.navigateByUrl('bookconcert');
 }

goToPageAdminConcert():void{
  this.router.navigateByUrl('concerts');
}
 

  ngOnInit(): void {
  }

}
